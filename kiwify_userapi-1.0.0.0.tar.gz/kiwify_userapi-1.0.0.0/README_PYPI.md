# kiwify-userAPI


![Versão](https://img.shields.io/badge/version-0.0.0.1-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://paulocesar-dev404.github.io/me-apoiando-online/)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/kiwify-userAPI/blob/main/docs/iniciando.md)



Obtenha detalhes de cursos da plataforma kiwify com a api de usuário,usando esta lib
---
- [x] Obter cursos inscritos
- [x] Obter detalhes de Aulas
- [x] Obter detalhes de um Curso

