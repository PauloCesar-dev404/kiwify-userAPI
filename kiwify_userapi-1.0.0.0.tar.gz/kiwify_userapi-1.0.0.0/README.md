<div align="center">
    <img src="./assets/kiwify_userAPI-logo.png" alt="kiwify_userAPI-logo" width="200"/> 

![Versão](https://img.shields.io/badge/version-1.0.0.0-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://paulocesar-dev404.github.io/me-apoiando-online/)
[![Sponsor](https://img.shields.io/badge/Documentation-green)](https://github.com/PauloCesar-dev404/kiwify-userAPI/blob/main/docs/iniciando.md)


<i>A biblioteca `kiwify_userAPI` facilita a análise de cursos na Kiwify.
</i>
  
  ---
</div>




###  Funcionalidades
- [x] Obter cursos inscritos.
- [x] Obter detalhes de Aulas.
- [x] Obter detalhes de um Curso.

Se tiver dúvidas ou sugestões, abra uma issue.

---

